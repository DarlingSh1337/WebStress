<?php

    
    $pvgehdjvpcjk = "page";
    
    session_start();
    ${$pvgehdjvpcjk} = "Invoice";
    require_once "header.php";
    $qxfmilfxckq = "network";
    if (isset($_GET["id"])) {
        $id      = (int) $_GET["id"];
        $plansql = $odb->prepare("SELECT * FROM `plans` WHERE `ID` = :id");
        $plansql->execute(array(
            ":id" => $id
        ));
        $row = $plansql->fetch();
        if ($row === NULL) {
            die("Plan not found");
        }
    } else {
        header("Location: purchase.php");
        die("Invalid TIcket ID");
    }
    $GetInfo  = $odb->query("SELECT * FROM `users` WHERE `username`= '" . $_SESSION["username"] . "'");
    $userInfo = $GetInfo->fetch(PDO::FETCH_ASSOC);
    $SQL      = $odb->prepare("SELECT COUNT(*),`planID`,`date` FROM `payments` WHERE `invoiceID` = :invid AND `status` != '2'");
    $SQL->execute(array(
        ":invid" => htmlentities($_GET["invoice"])
    ));
    $rowPlani = $SQL->fetch(PDO::FETCH_ASSOC);
    if (empty($_GET["invoice"]) || $rowPlani["COUNT(*)"] == "0") {
        $gwfytj           = "fpqtnrr";
        $epneywwl         = "cypwrka";
        $cypwrka          = "GetPlanInfo";
        $rand             = rand(1111111, 9999999);
        ${$gwfytj}        = "planInfo";
        
    
        
            //generating the transaction using coinpayments
            $error = '';
    require('./functions/coinpayments.inc.php');
  $cps = new CoinPaymentsAPI();
  $cps->Setup('41de58195009E3f1f2f7be98267205c5C1193c523d5A6d0636Db24B9bdDd5d47', 'ce0bdf4cfeb30e8ea6233e57d303c95f1f0e4af02795a2327be63b2b7208d6fc');
    $bal = $row['price'];
    $user = $_SESSION["username"];
  $req = array(
    'amount' => $bal,
    'currency1' => 'USD',
    'currency2' => 'BTC',
    'buyer_email' => 'generic-stress@gmail.com',
    'buyer_name' =>  $user,
    'item_name' => 'Membership buy',
    'address' => '', // leave blank send to follow your settings on the Coin Settings page
    'ipn_url' => 'https://sourceservices.club/lol/client/functions/awesome-hooker.php',
  );
  
      
  $result = $cps->CreateTransaction($req);
  if ($result['error'] == 'ok') {
      $btcid = $result['result']['txn_id'];
    $btcamount = $result['result']['amount'];
    $address = $result['result']['address'];
    $link = $result['result']['status_url'];
    $qr = $result['result']['qrcode_url'];
    $time = $result['result']['timeout'];
    
    //update the trans id
      
  }else{
$error = 'Looks like there is a problem getting the data.';
}
$ip = "N/A";
        $SQLCheckRegister = $odb->prepare("INSERT INTO `payments`(`ID`, `IP`, `planID`, `invoiceID`, `status`, `username`, `date`, `txid`, `btcamount`, `qr`, `address`) VALUES (NULL, :IP, :planID,:invoiceID,'0',:username,UNIX_TIMESTAMP(NOW()),:txid,:btc,:qr,:addr)");
        $SQLCheckRegister->execute(array(
            ":IP" => $ip,
            ":planID" => htmlentities($_GET["id"]),
            ":invoiceID" => $rand,
            ":username" => $_SESSION["username"],
            ":txid" => $btcid,
            ":qr" => $qr,
            ":btc" => $btcamount,
            ":addr" => $address
        ));

    //insert into notification
    $SQLinsert = $odb -> prepare("INSERT INTO `notifications` VALUES(NULL, ?, ?, ?, UNIX_TIMESTAMP())");
      $SQLinsert -> execute(array('You have an unpaid invoice', $_SESSION["username"], 0));
      
        ${${$epneywwl}} = $odb->query("SELECT *,COUNT(*) FROM `plans` WHERE `id`= '" . htmlentities($_GET["id"]) . "'");
        $planInfo       = $GetPlanInfo->fetch(PDO::FETCH_ASSOC);
        echo "<meta http-equiv=\"refresh\" content=\"\x30\x3b\x75\x72\x6c\x3d\x69\x6e\x76\x6f\x69\x63\x65\x2e\x70\x68\x70?\x69\x64\x3d" . htmlentities($_GET["id"]) . "&invoice=" . $rand . "\">";
        if (${$fpqtnrr}["COUNT(*)"] == "0") {
            die("<script>window.location = \"purchase.php\"</script>");
        }
    } else {
        $rand        = htmlentities($_GET["invoice"]);
        $GetPlanInfo = $odb->query("SELECT *,COUNT(*) FROM `plans` WHERE `id`= '" . htmlentities($rowPlani["planID"]) . "'");
        $planInfo    = $GetPlanInfo->fetch(PDO::FETCH_ASSOC);
    }
    $network = $planInfo["vip"];
    if (${$qxfmilfxckq} == 0) {
        $network = "false";
        $class = "badge badge-danger";
    } else {
        $network = "true";
        $class = "badge badge-success";
    }
    $api = $planInfo["api"];
    if ($api == 0) {
        $api = "false";
        $class2 = "badge badge-danger";
    } else {
        $api = "true";
        $class2 = "badge badge-success";
    }
    $SQL = $odb->prepare("SELECT * FROM `users` WHERE `username` = :usuario");
    $SQL->execute(array(
        ":usuario" => $_SESSION["username"]
    ));
    $balancex = $SQL->fetch();
    $balance  = $balancex["balance"];
    if (isset($_POST["buy"])) {
        if (number_format((float) $balance, 2, ".", "") >= number_format((float) $row["price"], 2, ".", "")) {
            $getPlanInfo = $odb->prepare("SELECT `unit`,`length`,`name` FROM `plans` WHERE `ID` = :plan");
            $getPlanInfo->execute(array(
                ":plan" => $id
            ));
            $kbdsbtqdjg       = "bhjhxmqnxn";
            $plan             = $getPlanInfo->fetch(PDO::FETCH_ASSOC);
            $unit             = $plan["unit"];
            $bhjhxmqnxn       = "length";
            ${${$kbdsbtqdjg}} = $plan["length"];
            $name             = $plan["name"];
            $newExpire        = strtotime("+{$length} {$unit}");
            $updateSQL        = $odb->prepare("UPDATE `users` SET `expire` = :expire, `membership` = :plan WHERE `id` = :id");
            $updateSQL->execute(array(
                ":expire" => $newExpire,
                ":plan" => $id,
                ":id" => $_SESSION["ID"]
            ));
            $balance   = number_format((float) $balance, 2, ".", "") - number_format((float) $row["price"], 2, ".", "");
            $updateSQL = $odb->prepare("UPDATE `users` SET `balance` = :balance WHERE `id` = :id");
            $updateSQL->execute(array(
                ":balance" => $balance,
                ":id" => $_SESSION["ID"]
            ));
            $SQLUpdate = $odb->prepare("UPDATE `payments` SET `status`= '2' WHERE `username` = :username AND `invoiceID` = :invid");
            $SQLUpdate->execute(array(
                ":username" => $_SESSION["username"],
                ":invid" => htmlentities($_GET["invoice"])
            ));
      
      $SQLinsert = $odb -> prepare("INSERT INTO `notifications` VALUES(NULL, ?, ?, ?, UNIX_TIMESTAMP())");
      $SQLinsert -> execute(array('Thanks For buy', $_SESSION["username"], 0));
            echo "<script type=\"text/javascript\">";
            echo "setTimeout(function () { swal(\"success!\",\x22Y\x6f\x75\x20\x68\x61\x76\x65\x20\x6e\x6f\x77\x20\x74\x68e\x20\x70\x6c\x61\x6e\x2e\x22,\x22\x73\x75\x63\x63\x65\x73\x73\x22)\x3b";
            echo "}, 1000);</script>";
        } else {
            echo "<script type=\"text/javascript\">";
            echo "setTimeout(function () { swal(\"Error!\",\"You need more money to buy this plan.\",\"error\");";
            echo "}, 1000);</script>";
        }
    }
    if (isset($_POST["btc"])) {
        header("Location: order.php?id=" . htmlentities($_GET["id"]) . "");
        die();
    }
  
    if (isset($_POST["cancel"])) {
    
    $SQLUpdate = $odb->prepare("UPDATE `payments` SET `status`= '1' WHERE `username` = :username AND `invoiceID` = :invid");
            $SQLUpdate->execute(array(
                ":username" => $_SESSION["username"],
                ":invid" => htmlentities($_GET["invoice"])
            ));
    echo "<script type=\"text/javascript\">";
            echo "setTimeout(function () { swal(\"Success!\",\"Invoice Canceled!.\",\"success\");";
            echo "}, 1000);</script>";
        echo '<meta http-equiv="refresh" content="3;url=payments.php">';
        
        
    }
$GetRequired = $odb->query("SELECT * FROM `payments` WHERE `invoiceID`= '" . htmlentities($_GET["invoice"]) . "'");
$data = $GetRequired->fetch(PDO::FETCH_ASSOC);
$thedate = date('d \of M Y', $data['date']);

?>


         <div class="container-fluid page-body-wrapper">
            <div class="main-panel">
               <div class="content-wrapper">
                  <div class="row">
                     <div class="col-xl-6 mt-3">
                        <div class="col-xl-12">
                           
                        </div>
                        <div class="col-xl-12 mt-3">
                           <div class="card mb-3">
                              <div class="card-body">
                                 <h4 class="card-title">BTC Payment</h4>
                                 <div class="form-group">
                                    <center>
                                      <img src="<?php echo $data['qr']; ?>" id="qr" alt="QR Code" width="150" height="150">
                                    </center>
                                 </div>
                                 <div class="form-group"><label for="">
                                    Amount to pay
                                    </label><input type="text" class="form-control" id=""  name="" maxlength="" value="<?php echo $data['btcamount']; ?>" placeholder="" onclick=this.select();document.execCommand(&#039;copy&#039;);alert(&#039;Copied&#039;);  />
                                 </div>
                                 <div class="form-group"><label for="">
                                    Payment address
                                    </label><input type="text" class="form-control" id=""  name="" maxlength="" value="<?php echo $data['address']; ?>" placeholder="" onclick=this.select();document.execCommand(&#039;copy&#039;);alert(&#039;Copied&#039;);  />
                                 </div>
                                 <form method="POST" action="https://webstress.net/request/invoice/manage/1884268622" >
                                    <input type="hidden" id="__csrf" name="__csrf" value="a614b595015560d077dc20f300e137c00n4b579le68kcerci8jqt1tgon443refCS176181184193refCSf29ad2a52f268d3977ea5426c28327a1"/>
                                    <div class="row">
                                       <div class="col-md-6"><button type="submit" name="refresh" value="1" class="btn btn-primary btn-block mt-3 mt-2"><i class="icon-refresh"></i> Refresh</button></div>
                                       <div class="col-md-6"><button type="submit" name="cancel" value="1" class="btn btn-danger btn-block mt-3 mt-2"><i class="icon-trash"></i> Cancel</button></div>
                                    </div>
                                 </form>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-6 mt-3">
                        <div class="col-xl-12">
                           <div class="card mb-3">
                              <div class="card-body">
                                 <h4 class="card-title">Invoice n°1884268622</h4>
                                 <table class="table">
                                    <tbody>
                                       <tr>
                                          <th scope="row">Plan</th>
                                          <td class="text-white" style="width: 20%"><?php echo $planInfo['name']; ?></td>
                                       </tr>
                                       <tr>
                                          <th scope="row">Price</th>
                                          <td class="text-white" style="width: 20%"><?php echo $planInfo['price']; ?></td>
                                       </tr>
                                       <tr>
                                          <th scope="row">Billing</th>
                                          <td class="text-white" style="width: 20%"><?php echo $planInfo['length']; ?>  <?php echo $planInfo['unit']; ?></td>
                                       </tr>
                                       <tr>
                                          <th scope="row">Attack Time</th>
                                          <td class="text-white" style="width: 20%"><?php echo $planInfo['mbt']; ?></td>
                                       </tr>
                                       <tr>
                                          <th scope="row">Slots</th>
                                          <td class="text-white" style="width: 20%"><?php echo $planInfo['concurrents']; ?></td>
                                       </tr>
                                       <tr>
                                          <th scope="row">Amplification Power (avg.)</th>
                                          <td class="text-white" style="width: 20%">10 Gbps</td>
                                       </tr>
                                       <tr>
                                          <th scope="row">Packets Per Second</th>
                                          <td class="text-white" style="width: 20%">400,000</td>
                                       </tr>
                                       <tr>
                                          <th scope="row">Premium</th>
                                          <td class="text-white" style="width: 20%"><span class="<?php echo $class; ?>"><?php echo $network; ?></span></td>
                                       </tr>
                                       <tr>
                                          <th scope="row">API Access</th>
                                          <td class="text-white" style="width: 20%"><span class="<?php echo $class2; ?>"><?php echo $api; ?></span></td>
                                       </tr>
                                       <tr>
                                          <th scope="row">Layer 7 Network</th>
                                          <td class="text-white" style="width: 20%"><span class="badge badge-danger">False</span></td>
                                       </tr>
                                    </tbody>
                                 </table>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>

               <?php include 'footer.php'; ?>
   </body>
</html>