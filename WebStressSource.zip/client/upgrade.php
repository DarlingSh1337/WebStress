<?php 
session_start();
$page = "Upgrade";
include 'header.php';
    $runningrip = $odb->query("SELECT COUNT(*) FROM `logs` WHERE `time` + `date` > UNIX_TIMESTAMP() AND `stopped` = 0")->fetchColumn(0);
   $slotsx = $odb->query("SELECT COUNT(*) FROM `api` WHERE `slots`")->fetchColumn(0);     
?>


                 <div class="container-fluid page-body-wrapper">
            <div class="main-panel">
               <div class="content-wrapper">
                  <div class="row">
                     <div class="col-xl-12 mt-3">
                        <div class="card">
                           <div class="card-body">
                              <h4 class="card-title">Select Plan</h4>
                              <ul class="nav nav-tabs tab-basic justify-content-center" role="tablist">
                                 <li class="nav-item"><a class="nav-link" data-toggle="tab" href="upgrade#Basic" role="tab" aria-selected="true"></a></li>
                                 <li class="nav-item"><a class="nav-link  show active" data-toggle="tab" href="upgrade#Premium" role="tab" aria-selected="false">Basic</a></li>
                                 <li class="nav-item"><a class="nav-link" data-toggle="tab" href="upgrade#Enterprise" role="tab" aria-selected="false"></a></li>
                              </ul>

                              <div class="tab-content tab-content-basic">
                                 <div class="tab-pane fade active show" id="Basic" role="tabpanel">
                                    <div class="table-responsive-lg">
                                       <table class="table">
                                          <thead>
                                             <tr>
                                                <th>Plan</th>
                                                <th>Billing</th>
                                                <th>Attack Time</th>
                                                <th>Slots</th>
                                                <th>Power</th>
                                                <th>API</th>
                                                <th>Premium</th>
                                                <th>Layer 7</th>
                                                <th>Order</th>
                                             </tr>
                                          </thead>
                                          


                              <?php
                                    $SQLGetPlans = $odb -> query("SELECT * FROM `plans` WHERE `private` = 0 ORDER BY `ID` ASC");
                                    while ($getInfo = $SQLGetPlans -> fetch(PDO::FETCH_ASSOC))
                                    {
                           $id = $getInfo['ID'];
                           $name = $getInfo['name'];
                           $price = $getInfo['price'];
                           $length = $getInfo['length'];
                           $unit = $getInfo['unit'];
                           $concurrents = $getInfo['concurrents'];
                           $mbt = $getInfo['mbt'];
                           $network = $getInfo['vip'];
                           $api = $getInfo['api'];
                           $totalservers = $getInfo['totalservers'];
                                             
                           if($network == "0")
                           {
                              $network = '<b class="text-primary"><i class="fa fa-feed text-warning"></i> False</b>';
                              $colorx = 'bg-body-light';
                              $l4= '<strong>Layer 4 </strong><span class="text-success font-w700"></i>  &#10004; </span>';
                              $l7= '<strong>Layer 7 </strong><span class="text-success font-w700"></i> &#10004; </span>';
                              $b4= '<strong>Bypass Layer 4 </strong><span class="text-danger font-w700"></i>  &#10006; </span>';
                              $b7= '<strong>Bypass Layer 7 </strong><span class="text-danger font-w700"></i>  &#10006;</span>';
                              
                              
                              
                           }elseif($network == "1")
                           {
                              $network = '<span class="text-danger font-w700"></i> True <i class="si si-fire text-warning"></i></span>';
                              $colorx = '';
                              $l4= '<strong>Layer 4 </strong><span class="text-success font-w700"></i>  &#10004; </span>';
                              $l7= '<strong>Layer 7 </strong><span class="text-success font-w700"></i> &#10004; </span>';
                              $b4= '<strong>Bypass Layer 4 </strong><span class="text-success font-w700"></i>  &#10004; </span>';
                              $b7= '<strong>Bypass Layer 7 </strong><span class="text-success font-w700"></i>  &#10004;</span>';
                           }
                           if($api == "0")
                           {
                              $api = '<span class="text-success font-w700"></i> False <i class="fa fa-bolt text-secondary"></i></span>';
                           }elseif($api == "1")
                           {
                              $api = '<span class="text-primary font-w700"></i> True <i class="si si-fire text-success"></i></span>';
                           }
                       
                           
               
                              
echo '<tr>
                                                <td>
                                                   <h6 class="text-white font-weight-normal">'.htmlspecialchars($name).'</h6>
                                                </td>
                                                <td>
                                                   <h4 class="text-primary font-weight-normal">$'.htmlentities($price).'</h4>
                                                   <p class="text-muted mb-0">'.htmlentities($length).' '.htmlspecialchars($unit).'</p>
                                                </td>
                                                <td>
                                                   '.htmlentities($mbt).'
                                                </td>
                                                <td>
                                                   '.$concurrents.'
                                                </td>
                                                <td>
                                                   <p>400,000 PPS <small>* Packets per seconds</small></p>
                                                   <p class="text-muted mb-0">10 Gbps AMP <small>* Gigabits per seconds</small></p>
                                                </td>
                                                <td><span class="badge badge-danger">'.$api.'</span></td>
                                                <td><span class="badge badge-danger">'.$network.'</span></td>
                                                <td><span class="badge badge-danger">'.$l7.'</span></td>
                                                <td><a href="invoice.php?id='. $id .'" class="btn btn-icons btn-rounded btn-dark"><i class="icon-basket"></i></a></td>
                                             </tr>

                                             ';
?>

<?php

 }

?>
                                 </tbody>
                                       </table>
                                    </div>

                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>




                     <div class="container-fluid page-body-wrapper">
            <div class="main-panel">
               <div class="content-wrapper">
                  <div class="row">
                     <div class="col-xl-12 mt-3">
                        <div class="card">
                           <div class="card-body">
                              <h4 class="card-title">Select Plan</h4>
                              <ul class="nav nav-tabs tab-basic justify-content-center" role="tablist">
                                 <li class="nav-item"><a class="nav-link" data-toggle="tab" href="upgrade#Basic" role="tab" aria-selected="true"></a></li>
                                 <li class="nav-item"><a class="nav-link show active" data-toggle="tab" href="upgrade#Premium" role="tab" aria-selected="false">Premium</a></li>
                                 <li class="nav-item"><a class="nav-link" data-toggle="tab" href="upgrade#Enterprise" role="tab" aria-selected="false"></a></li>
                              </ul>

                              <div class="tab-content tab-content-basic">
                                 <div class="tab-pane fade active show" id="Basic" role="tabpanel">
                                    <div class="table-responsive-lg">
                                       <table class="table">
                                          <thead>
                                             <tr>
                                                <th>Plan</th>
                                                <th>Billing</th>
                                                <th>Attack Time</th>
                                                <th>Slots</th>
                                                <th>Power</th>
                                                <th>API</th>
                                                <th>Premium</th>
                                                <th>Layer 7</th>
                                                <th>Order</th>
                                             </tr>
                                          </thead>
                                          


                              <?php
                                    $SQLGetPlans = $odb -> query("SELECT * FROM `plans` WHERE `private` = 0 ORDER BY `ID` ASC");
                                    while ($getInfo = $SQLGetPlans -> fetch(PDO::FETCH_ASSOC))
                                    {
                           $id = $getInfo['ID'];
                           $name = $getInfo['name'];
                           $price = $getInfo['price'];
                           $length = $getInfo['length'];
                           $unit = $getInfo['unit'];
                           $concurrents = $getInfo['concurrents'];
                           $mbt = $getInfo['mbt'];
                           $network = $getInfo['vip'];
                           $api = $getInfo['api'];
                           $totalservers = $getInfo['totalservers'];
                                             
                           if($network == "0")
                           {
                              $network = '<b class="text-primary"><i class="fa fa-feed text-warning"></i> False</b>';
                              $colorx = 'bg-body-light';
                              $l4= '<strong>Layer 4 </strong><span class="text-success font-w700"></i>  &#10004; </span>';
                              $l7= '<strong>Layer 7 </strong><span class="text-success font-w700"></i> &#10004; </span>';
                              $b4= '<strong>Bypass Layer 4 </strong><span class="text-danger font-w700"></i>  &#10006; </span>';
                              $b7= '<strong>Bypass Layer 7 </strong><span class="text-danger font-w700"></i>  &#10006;</span>';
                              
                              
                              
                           }elseif($network == "1")
                           {
                              $network = '<span class="text-danger font-w700"></i> True <i class="si si-fire text-warning"></i></span>';
                              $colorx = '';
                              $l4= '<strong>Layer 4 </strong><span class="text-success font-w700"></i>  &#10004; </span>';
                              $l7= '<strong>Layer 7 </strong><span class="text-success font-w700"></i> &#10004; </span>';
                              $b4= '<strong>Bypass Layer 4 </strong><span class="text-success font-w700"></i>  &#10004; </span>';
                              $b7= '<strong>Bypass Layer 7 </strong><span class="text-success font-w700"></i>  &#10004;</span>';
                           }
                           if($api == "0")
                           {
                              $api = '<span class="text-success font-w700"></i> False <i class="fa fa-bolt text-secondary"></i></span>';
                           }elseif($api == "1")
                           {
                              $api = '<span class="text-primary font-w700"></i> True <i class="si si-fire text-success"></i></span>';
                           }
                       
                           
               
                              
echo '<tr>
                                                <td>
                                                   <h6 class="text-white font-weight-normal">'.htmlspecialchars($name).'</h6>
                                                </td>
                                                <td>
                                                   <h4 class="text-primary font-weight-normal">$'.htmlentities($price).'</h4>
                                                   <p class="text-muted mb-0">'.htmlentities($length).' '.htmlspecialchars($unit).'</p>
                                                </td>
                                                <td>
                                                   '.htmlentities($mbt).'
                                                </td>
                                                <td>
                                                   '.$concurrents.'
                                                </td>
                                                <td>
                                                   <p>400,000 PPS <small>* Packets per seconds</small></p>
                                                   <p class="text-muted mb-0">10 Gbps AMP <small>* Gigabits per seconds</small></p>
                                                </td>
                                                <td><span class="badge badge-danger">'.$api.'</span></td>
                                                <td><span class="badge badge-danger">'.$network.'</span></td>
                                                <td><span class="badge badge-danger">'.$l7.'</span></td>
                                                <td><a href="invoice.php?id='. $id .'" class="btn btn-icons btn-rounded btn-dark"><i class="icon-basket"></i></a></td>
                                             </tr>

                                             ';
?>

<?php

 }

?>
                                 </tbody>
                                       </table>
                                    </div>

                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>

                  <div class="row">
                     <div class="col-xl-12 mt-3">
                        <div class="card mb-3">
                           <div class="card-body">
                              <h4 class="card-title">Documentation</h4>
                              <div class="accordion accordion-bordered" id="accordion-2" role="tablist">
                                 <div class="row">
                                    <div class="col-xl-6">
                                       <div class="card">
                                          <div class="card-header" role="tab" id="heading-4">
                                             <h6 class="mb-0"><a data-toggle="collapse" href="upgrade#collapse-4" aria-expanded="false" aria-controls="collapse-4" class="collapsed">
                                                What is Attack Time ?
                                                </a>
                                             </h6>
                                          </div>
                                          <div id="collapse-4" class="collapse" role="tabpanel" aria-labelledby="heading-4" data-parent="#accordion-2" style="">
                                             <div class="card-body">
                                                Attack Time indicates how long you can launch an attack per target in seconds.
                                             </div>
                                          </div>
                                       </div>
                                       <div class="card">
                                          <div class="card-header" role="tab" id="heading-5">
                                             <h6 class="mb-0"><a class="collapsed" data-toggle="collapse" href="upgrade#collapse-5" aria-expanded="false" aria-controls="collapse-5">
                                                What is Amplification Power ?
                                                </a>
                                             </h6>
                                          </div>
                                          <div id="collapse-5" class="collapse" role="tabpanel" aria-labelledby="heading-5" data-parent="#accordion-2" style="">
                                             <div class="card-body">
                                                Amplification Power is the average amount of gigabit per second which can be sent per concurrent with our udp amplification methods. Keep in mind that this is an average value which depends on several factors like response size, amplification factor of the udp protocol, etc.
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-xl-6">
                                       <div class="card">
                                          <div class="card-header" role="tab" id="heading-6">
                                             <h6 class="mb-0"><a data-toggle="collapse" href="upgrade#collapse-6" aria-expanded="false" aria-controls="collapse-6" class="collapsed">
                                                What is API Access ?
                                                </a>
                                             </h6>
                                          </div>
                                          <div id="collapse-6" class="collapse" role="tabpanel" aria-labelledby="heading-6" data-parent="#accordion-2" style="">
                                             <div class="card-body">
                                                API Access is a feature that will allow you to use our services from your own applications.
                                             </div>
                                          </div>
                                       </div>
                                       <div class="card">
                                          <div class="card-header" role="tab" id="heading-7">
                                             <h6 class="mb-0"><a class="collapsed" data-toggle="collapse" href="upgrade#collapse-7" aria-expanded="false" aria-controls="collapse-7">
                                                What is Premium Network ?
                                                </a>
                                             </h6>
                                          </div>
                                          <div id="collapse-7" class="collapse" role="tabpanel" aria-labelledby="heading-7" data-parent="#accordion-2" style="">
                                             <div class="card-body">
                                                Premium give you access to our L4/L7 custom bypass methods and our custom features like Schedule Attack.
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-xl-6">
                                       <div class="card">
                                          <div class="card-header" role="tab" id="heading-8">
                                             <h6 class="mb-0"><a data-toggle="collapse" href="upgrade#collapse-8" aria-expanded="false" aria-controls="collapse-8" class="collapsed">
                                                How to get a custom plan ?
                                                </a>
                                             </h6>
                                          </div>
                                          <div id="collapse-8" class="collapse" role="tabpanel" aria-labelledby="heading-8" data-parent="#accordion-2" style="">
                                             <div class="card-body">
                                                Contact-us by ticket.
                                             </div>
                                          </div>
                                       </div>
                                       <div class="card">
                                          <div class="card-header" role="tab" id="heading-7">
                                             <h6 class="mb-0"><a class="collapsed" data-toggle="collapse" href="upgrade#collapse-9" aria-expanded="false" aria-controls="collapse-9">
                                                What are Concurrents ?
                                                </a>
                                             </h6>
                                          </div>
                                          <div id="collapse-9" class="collapse" role="tabpanel" aria-labelledby="heading-9" data-parent="#accordion-2" style="">
                                             <div class="card-body">
                                                Concurrents are the amount of attack you can run at the same time. Each concurrent is handled by a different server.
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-xl-6">
                                       <div class="card">
                                          <div class="card-header" role="tab" id="heading-10">
                                             <h6 class="mb-0"><a data-toggle="collapse" href="upgrade#collapse-10" aria-expanded="false" aria-controls="collapse-10" class="collapsed">
                                                What is Packet Per Seconds ?
                                                </a>
                                             </h6>
                                          </div>
                                          <div id="collapse-10" class="collapse" role="tabpanel" aria-labelledby="heading-10" data-parent="#accordion-2" style="">
                                             <div class="card-body">
                                                Packet Per Seconds (PPS or P/S) is the amount of packets per second can be sent per concurrent.
                                             </div>
                                          </div>
                                       </div>
                                       <div class="card">
                                          <div class="card-header" role="tab" id="heading-11">
                                             <h6 class="mb-0"><a class="collapsed" data-toggle="collapse" href="upgrade#collapse-11" aria-expanded="false" aria-controls="collapse-11">
                                                What is Month(s) ?
                                                </a>
                                             </h6>
                                          </div>
                                          <div id="collapse-11" class="collapse" role="tabpanel" aria-labelledby="heading-11" data-parent="#accordion-2" style="">
                                             <div class="card-body">
                                                Duration of your subscription in month.
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>

               <script src="https://shoppy.gg/api/embed.js"></script>
               <?php include 'footer.php'; ?>
   </body>
</html>