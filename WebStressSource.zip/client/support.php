<?php
$name = "Support";
include 'header.php';
?>


<div class="container-fluid page-body-wrapper">
            <div class="main-panel">
               <div class="content-wrapper">
                  <div class="row">
                     <div class="col-xl-12 mt-3">
                        <div class="card">
                           <div class="container-fluid">

                              <div class="row">
                     <div class="col-xl-12 mt-3"><a target="_BLANK" href="https://t.me/webstresse"><img src="assets/telegram.png" alt="Telegram"></a></div>
                  </div>

<div class="row">
<div style="text-align:center" class="col-lg-12">
<div class="card">
</div>
</div>
<div style="text-align:center" class="col-lg-6">
<div class="card">
<div class="card-header text-uppercase">Contact EMAIL</div>
<div class="card-body">
<input type="text" readonly="readonly" value="darlingsh1337@protonmail.com" class="form-control">
</div>
</div>
</div>
<div style="text-align:center" class="col-lg-6">
<div class="card">
<div class="card-header text-uppercase">Contact Telegram</div>
<div class="card-body">
<input type="text" readonly="readonly" value="@DarlingSh" class="form-control">
</div>
</div>
</div>
</div>
<div class="row">
<div style="text-align: center" class="col-12 col-lg-6">
<div class="card">
<div class="card-body">
<div class="card-title" style="
    color: #fec544 !important;
">WHAT IS A DDOS ATTACK
</div>
<p>A cyber-attack whic seeks to make a machine or network resource unavailable to its intended users by temporarily disrupting services of a host connected to the Internet. For example taking a website offline, an API used by a mobile application, someones internet connection or a game server.</p>
</div>
</div>
</div>
<div style="text-align: center" class="col-12 col-lg-6">
<div class="card">
<div class="card-body">
<div class="card-title" style="
    color: #fec544 !important;
">WHAT IS Webstress.gg </div>
<p>Webstress.gg its an advanced tool that allows you to test your services agaisnt real time strong DDOS attacks with the latest methods used by hackers to attack companies, such as botnets and ddos-mitigation bypasses. With the intend to help you find out if your website or server can be taken down.</p>
</div>
</div>
</div>
<div style="text-align: center" class="col-12 col-lg-6">
<div class="card">
<div class="card-body">
<div class="card-title" style="
    color: #fec544 !important;
">IS IT SAFE TO USE?
</div>
<p>Yes! it is, all attacks are untraceable and we do an excellent job protecting our customers. We do not keep any kind of records that can compromise your privacy and even usernames are encrypted with the strongest algorithms to ensure your safety!</p>
</div>
</div>
</div>
<div style="text-align: center" class="col-12 col-lg-6">
<div class="card">
<div class="card-body">
<div class="card-title" style="
    color: #fec544 !important;
">WHAT CAN IT ATTACK?
</div>
<p>Our service is oriented towards attacking websites and we count with bypasses for Cloudflare (CF), CF Under Attack Mode, Sucuri, Blazingfast, among others. We also provide a decent Layer 4 to attack residential connections and weak servers.</p>
</div>
</div>
</div>
<div style="text-align: center" class="col-12 col-lg-6">
<div class="card">
<div class="card-body">
<div class="card-title" style="
    color: #fec544 !important;
">HOW DO I GET A PLAN?
</div>
<p>Go to the purchase pages in the left navigation bar and select your prefered plan, then you will be asked for an email. Make sure to use a valid email, we recommend creating a new one. Right after you pay a code will be sent to your email, you need to redeem it in our codes page!</p>
</div>
</div>
</div>
<div style="text-align: center" class="col-12 col-lg-6">
<div class="card">
<div class="card-body">
<div class="card-title" style="
    color: #fec544 !important;
">CAN I UPGRADE MY PLAN?
</div>
<p>Yes, you can. Contact me and telegram / email and provide your username and the desired plan, depending on the remaining time of your current plan you will be offered a certain discount to move to the choosen plan, then you pay the amount and kaboom! You get your plan.</p>
</div>
</div>
</div>
</div>
</div>
<?php include 'footer.php'; ?>
   </body>
</html>