<?php 
session_start();
$page = "Home";
include 'header.php';

       $lastactive = $odb -> prepare("UPDATE `users` SET activity=UNIX_TIMESTAMP() WHERE username=:username");
       $lastactive -> execute(array(':username' => $_SESSION['username']));

    $onedayago = time() - 86400;

    $twodaysago = time() - 172800;
    $twodaysago_after = $twodaysago + 86400;

    $threedaysago = time() - 259200;
    $threedaysago_after = $threedaysago + 86400;

    $fourdaysago = time() - 345600;
    $fourdaysago_after = $fourdaysago + 86400;

    $fivedaysago = time() - 432000;
    $fivedaysago_after = $fivedaysago + 86400;

    $sixdaysago = time() - 518400;
    $sixdaysago_after = $sixdaysago + 86400;

    $sevendaysago = time() - 604800;
    $sevendaysago_after = $sevendaysago + 86400;
    
    $SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` > :date");
    $SQL -> execute(array(":date" => $onedayago));
    $count_one = $SQL->fetchColumn(0);

    $SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after");
    $SQL -> execute(array(":before" => $twodaysago, ":after" => $twodaysago_after));
    $count_two = $SQL->fetchColumn(0);

    $SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after");
    $SQL -> execute(array(":before" => $threedaysago, ":after" => $threedaysago_after));
    $count_three = $SQL->fetchColumn(0);

    $SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after");
    $SQL -> execute(array(":before" => $fourdaysago, ":after" => $fourdaysago_after));
    $count_four = $SQL->fetchColumn(0);

    $SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after");
    $SQL -> execute(array(":before" => $fivedaysago, ":after" => $fivedaysago_after));
    $count_five = $SQL->fetchColumn(0);

    $SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after");
    $SQL -> execute(array(":before" => $sixdaysago, ":after" => $sixdaysago_after));
    $count_six = $SQL->fetchColumn(0);

    $SQL = $odb -> prepare("SELECT COUNT(*) FROM `logs` WHERE `date` BETWEEN :before AND :after");
    $SQL -> execute(array(":before" => $sevendaysago, ":after" => $sevendaysago_after));
    $count_seven = $SQL->fetchColumn(0);

    
    $date_one = date('d/m/Y', $onedayago);
    $date_two = date('d/m/Y', $twodaysago);
    $date_three = date('d/m/Y', $threedaysago);
    $date_four = date('d/m/Y', $fourdaysago);
    $date_five = date('d/m/Y', $fivedaysago);
    $date_six = date('d/m/Y', $sixdaysago);
    $date_seven = date('d/m/Y', $sevendaysago);


      $plansql = $odb -> prepare("SELECT `users`.`expire`, `plans`.`name`, `plans`.`concurrents`, `plans`.`mbt` FROM `users`, `plans` WHERE `plans`.`ID` = `users`.`membership` AND `users`.`ID` = :id");
      $plansql -> execute(array(":id" => $_SESSION['ID']));
      $row = $plansql -> fetch(); 
      $date = date("m-d-Y, h:i:s a", $row['expire']);
      if (!$user->hasMembership($odb)){
        $row['mbt'] = 0;
        $row['concurrents'] = 0;
        $row['membership'] = 'n/a';
        $date = 'n/a';
        $SQLupdate = $odb -> prepare("UPDATE `users` SET `expire` = 0 WHERE `username` = ?");
        $SQLupdate -> execute(array($_SESSION['username']));
      }
      
      $SQL = $odb -> prepare("SELECT * FROM `users` WHERE `username` = :usuario");
                    $SQL -> execute(array(":usuario" => $_SESSION['username']));
                    $balancebyripx = $SQL -> fetch();
                    $balance = $balancebyripx['balance'];
          
          
          if ($user -> isAdmin($odb)){ 
        
        $rank =' <span class="badge badge-primary shadow-primary m-1"> Administrateur</span>';
         
        }
        
        else if ($user -> isVip($odb)){ 
        
          $rank =' <span class="badge badge-primary shadow-primary m-1"> Advance User</span>';
        }
        else if ($user -> hasMembership($odb)){ 
        
          $rank =' <span class="badge badge-primary shadow-primary m-1"> Paid</span>';
        }
        else if ($user -> isSupport($odb)){ 
        
          $rank =' <span class="badge badge-primary shadow-primary m-1"> Staff</span>';
        }
        else { 
        
          $rank =' <span class="badge badge-primary shadow-primary m-1"> Free </span>';
        }
        
      
    
      if (isset($_GET['wel']))
    {
        
        {
          
          echo '<script type="text/javascript">';
  echo 'setTimeout(function () { swal({
  position: "top-end",
  toast: "true",
  type: "info",
  title: "Welcome back '. $_SESSION['username'] .' WebStress.gg !",
  showConfirmButton: false,
  timer: 4500
  
});';
  echo ' }, 1000);</script>';
  
        }
        
      }
      
      
      
    ?>
         <div class="container-fluid page-body-wrapper">
            <div class="main-panel">
               <div class="content-wrapper">
                  <div class="row">
                     <div class="col-xl-12 mt-3">
                        <div class="card mb-3">
                           <div class="card-body">
                              <h3 class="card-title">All updates</h3>
                              <?php 
              $SQLGetNews = $odb -> query("SELECT * FROM `news` ORDER BY `date` DESC LIMIT 5");
              while ($getInfo = $SQLGetNews -> fetch(PDO::FETCH_ASSOC)){
                $id = $getInfo['ID'];
                $title = $getInfo['title'];
                   $color = $getInfo['color'];

                  $icon = $getInfo['icon'];
                $content = $getInfo['content'];
                $date9 = _ago($getInfo['date']);
                echo '<a href="update" style="text-decoration: none">
                                 <div class="card rounded border mb-2">
                                    <div class="card-body p-3">
                                       <div class="media">
                                          <i class="icon-grid icon-sm align-self-center mr-3"></i>
                                          <div class="media-body">
                                             <h6 class="mb-1">'.htmlspecialchars($title).'</h6>
                                             <p class="mb-2 mt-2 font-weight-bold text-muted">'.$content.'
                                             </p>
                                             <p class="mb-0 text-muted"><i class="icon-clock"></i> Created '.$date9.' ago
                                             </p>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </a>';
              }
              ?>

<?php include 'footer.php'; ?>
   </body>
</html>