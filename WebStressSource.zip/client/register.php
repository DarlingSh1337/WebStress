<?php 
         ob_start();
       require_once 'includes/configuration.php';
       require_once 'includes/init.php';
       $page = "Register Portal";
     
         if ($user -> LoggedIn()){
     header('Location: home');
     exit;
       }
     
               //Set IP (are you using cloudflare?)
  if ($cloudflare_set == 1){
    $ip = $_SERVER["HTTP_CF_CONNECTING_IP"];
  }
  else{
    $ip = $_SERVER["REMOTE_ADDR"];
  }
     
unset($_SESSION['captcha']);
$_SESSION['captcha'] = rand(1, 100);
$x1 = rand(2,15);
$x2 = rand(1,20);
$x = SHA1(($x1 + $x2).$_SESSION['captcha']);
 
      //VPN Detection       

/* $apiurl = 'https://www.ipqualityscore.com/api/json/ip/yx3K0H8IoNTqtGO7oGfNr4ntbp53fnkP/'. $ip;
      
           # api with curl
                                            $ch = curl_init();
                                            curl_setopt($ch, CURLOPT_URL, $apiurl);
                                            curl_setopt($ch, CURLOPT_HEADER, false);
                                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                            curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
                                            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
                                            $data = curl_exec($ch);
                                            curl_close($ch);
   
  $getInfo = json_decode($data, true); 
  $resul = $getInfo['vpn'];
  $true = 'true'; */

    //VPN Detection end

//DDoS Protection start
/*if(!empty($_COOKIE['ddos_key']))
    {
            end();
    }
    else 
        {

    header('Location: verify.php');

    } */
//End

      if(empty($_COOKIE['theme']))
    {
    $SQLC = $odb->prepare("SELECT `theme` FROM `settings` LIMIT 1");
          $SQLC -> execute();
                    $themee = $SQLC -> fetchColumn(0);
            $theme = $themee;
    }
else
{
            $theme = $_COOKIE['theme'];;
    } 

    $publickey = '6LeNX7wZAAAAAL2eHmEIuhlCArHJT9qyTsdQWoId';



?>

<!DOCTYPE html>
<html lang="en">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0,minimal-ui">
      <title><?php echo $sitename; ?> - <?php echo $page; ?></title>
      <link rel="shortcut icon" sizes="196x196" href="logo.png">
      <link rel="apple-touch-icon" href="logo.png" sizes="120x120">
      <link rel="apple-touch-icon" href="logo.png" sizes="152x152">
      <link rel="apple-touch-icon" href="logo.png" sizes="180x180">
      <link rel="shortcut icon" href="logo.png">
      <meta content="Welcome to Login of Webstress the best IP Stresser / booter in 2020, Login today and start boot for free." name="description">
      <meta name="keywords" content="free ip stresser,free ip booter,booter,ip stresser,stresser,booter">
      <meta name="msapplication-TileColor" content="#FFFFFF">
      <meta name="msapplication-TileImage" content="https://webstress.gg/app/landing/assets/img/icons/favicon-144.png">
      <meta name="msapplication-config" content="https://webstress.gg/app/landing/assets/img/icons/browserconfig.xml">
      <link rel="canonical" href="https://webstress.gg/login">
      <meta name="audience" content="all">
      <meta name="author" content="Webstress.gg">
      <meta property="og:type" content="website">
      <meta property="og:locale" content="en_US">
      <meta property="og:description" content="Webstress is the best IP Stresser / Booter ! We provide free and paid services.">
      <meta property="og:site_name" content="Webstress.gg">
      <meta property="og:url" content="https://webstress.gg/login">
      <meta property="og:image" content="logo.png">
      <meta property="og:title" content="Webstress is the best IP Stresser / Booter">
      <script async="" src="assets/app.js" charset="UTF-8" crossorigin="*"></script><script type="text/javascript" async="" src="assets/atrk.js"></script><script async="" src="assets/1epjsbcvf" charset="UTF-8" crossorigin="*"></script><script type="application/ld+json">{"@context": "https://schema.org","@type": "Organization","name": "Webstress","url": "https://Webstress.gg","logo": "https://webstress.gg/src/landing/assets/img/logo.png"}</script>
      <meta name="twitter:card" content="summary">
      <meta name="twitter:site" content="Webstress.gg">
      <meta name="twitter:title" content="WebStress - The best IP Stresser / Booter">
      <meta name="twitter:domain" content="Webstress.gg">
      <meta name="twitter:creator" content="">
      <meta name="twitter:description" content="Webstress is the best IP Stresser / booter in 2020, We also provide free and paid ip stresser / booter services">
      <meta name="twitter:image" content="https://webstress.gg/app/landing/assets/img/logo.png">
      <link rel="stylesheet" href="assets/template.min.css">
      <link href="assets/toastr.min.css" rel="stylesheet">
      <script async="" src="assets/js"></script><script>
         window.dataLayer = window.dataLayer || [];
         function gtag(){dataLayer.push(arguments);}
         gtag('js', new Date());
         gtag('config', 'UA-184475903-1');
      </script>
      <script src='https://www.google.com/recaptcha/api.js'></script>
   </head>
   <script>
    var answer="<?php echo $x; ?>";
</script>
   <body>
      <div class="accountbg">
      <div class="container-scroller">
         <div class="container-fluid page-body-wrapper">
            <div class="main-panel">
               <div class="content-wrapper">
                  <div class="row d-flex justify-content-center login-form">
                     <div class="col-md-8">
                        <div class="card">
                           <div class="card-body">
                              <center><img class="row" src="assets/logo.png" alt="WebStress Logo" style="margin-bottom: 3%;"></center>
                              <div class="row">
                                 <div class="col-xl-7">
<form class="form-horizontal form-material" id="regsiterform">
<h1 class="card-title">Register portal</h1>
<div id="alert" style="display:none"></div>
<div class="form-group">
<div class="form-material floating">

<input type="text" id="username" class="form-control" placeholder="Username">
</div>
</div>
<div class="form-group">
<div class="form-material floating">

<input type="text" id="email" class="form-control" placeholder="Email">
</div>
</div>
<div class="form-group">
<div class="form-material floating">

 <input type="password" id="password" class="form-control" placeholder="Password">
</div>
</div>
<div class="form-group">
<div class="form-material floating">

 <input type="password" id="rpassword" class="form-control" placeholder="Verify Password">
</div>
</div>

<div class="form-group">

<center><div class="g-recaptcha" id="captcha" data-sitekey="<?php echo $publickey; ?>"></div></center>

</div>

<div class="form-group">
<div class="icheck-material-primary">
<input type="checkbox" id="terms" value="yes" checked="" />
<label for="terms">I Agree With <a data-toggle="modal" data-target="#myModal" role="button" style="text-decoration:none; color:white;">TOS</a></label>
</div>
</div>

</form>


<div id="hidebtn" >
<button class="btn btn-primary btn-block" id="register" onclick="register()">
<i class="si si-login mr-10"></i> Create account
</button>
</div>
  <div class="col-12 mb-10">
<div id="loader" style="display:none">
<button class="btn btn-primary btn-block" id="login2" onclick="register2()">
<i class="si si-login mr-10"></i> please wait...<i class="fa fa-spinner fa-spin "></i>
</button>
</div>
</div>
</div>
                                 <div class="border-left ml-3"></div>
                                 <div class="col-xl-4 ml-4 login-custom">
                                    <h5>
                                       <center>WebStress.gg</center>
                                    </h5>
                                    <h1 class="login-h1">
                                       <small>
                                          <center><i>Register before use the IP Stresser service</i></center>
                                       </small>
                                    </h1>
                                    <div class="border-bottom mb-3 mt-3"></div>
                                    <p>Are you ready to register on the best ip stresser / booter of 2021 !</p>
                                    <p>Why register on this ip stresser / booter ?</p>
                                    <ul>
                                       <li>We are the best free ip stresser of 2021.</li>
                                       <li>We have the strongest layer4 and layer7 network.</li>
                                       <li>We have a support team always available for you.</li>
                                       <li>We provide a free ip stresser if you want to try before buy.</li>
                                       <li>Join the ip stresser / booter <a href="https://t.me/webstressdotnet/">Telegram</a>.</li>
                                    </ul>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>

<?php include 'footer.php'; ?>

<!-- Bootstrap core JavaScript-->
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/popper.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
  
  <!-- sidebar-menu js -->
  <script src="assets/js/sidebar-menu.js"></script>
  
  <!-- Custom scripts -->
  <script src="assets/js/app-script.js"></script>
  
    <script>
function register()
{
var username=$('#username').val();
var email=$('#email').val();
var password=$('#password').val();
var rpassword=$('#rpassword').val();
var captcha = $('#g-recaptcha-response').val();
document.getElementById("alert").style.display="none";
document.getElementById("loader").style.display="inline";
document.getElementById("hidebtn").style.display="none";
var xmlhttp;
if (window.XMLHttpRequest)
  {
  xmlhttp=new XMLHttpRequest();
  }
else
  {
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("alert").innerHTML=xmlhttp.responseText;
  document.getElementById("loader").style.display="none";
  document.getElementById("alert").style.display="inline";
    document.getElementById("hidebtn").style.display="inline";
  if (xmlhttp.responseText.search("Registered Successfully!!") != -1)
  {
            swal({
  position: 'center',
  toast: false,
  type: 'success',
  title: 'Registered successfully!',
  showConfirmButton: true,
  timer: 2500
  
});

    }
    }
  }
xmlhttp.open("POST","functions/login.php?type=register",true);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("username=" + username + "&email=" + email + "&password=" + password + "&rpassword=" + rpassword + "&captcha=" + grecaptcha.getResponse());
}
</script>
<script src="assets/node_modules/sweetalert2/dist/sweetalert2.all.min.js"></script>
        <link rel="stylesheet" href="assets/node_modules/sweetalert2/dist/sweetalert2.min.css">
   <script src="assets/toastr/toastr.min.js"></script>
     
  
</body>
</html>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5d5281c677aa790be32eac19/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

   </body>
</html>