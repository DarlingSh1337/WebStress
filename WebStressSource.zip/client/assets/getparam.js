function unserialize(data){
	var error = function (type, msg, filename, line){
		throw new window[type](msg, filename, line);
	};
	var read_until = function (data, offset, stopchr){
		var buf = [];
		var chr = data.slice(offset, offset + 1);
		var i = 2;
		while(chr !== stopchr){
			if((i+offset) > data.length){
				error('Error', 'Invalid');
			}
			buf.push(chr);
			chr = data.slice(offset + (i - 1),offset + i);
			i += 1;
		}
		return [buf.length, buf.join('')];
	};
	var read_chrs = function (data, offset, length){
		buf = [];
		for(var i = 0;i < length;i++){
			var chr = data.slice(offset + (i - 1),offset + i);
			buf.push(chr);
		}
		return [buf.length, buf.join('')];
	};
	var _unserialize = function (data, offset){
		if(!offset) offset = 0;
		var buf = [];
		var dtype = (data.slice(offset, offset + 1)).toLowerCase();

		var dataoffset = offset + 2;
		var typeconvert = new Function('x', 'return x');
		var chrs = 0;
		var datalength = 0;

		switch(dtype){
			case "i":
				typeconvert = new Function('x', 'return parseInt(x)');
				var readData = read_until(data, dataoffset, ';');
				var chrs = readData[0];
				var readdata = readData[1];
				dataoffset += chrs + 1;
				break;
			case "b":
				typeconvert = new Function('x', 'return (parseInt(x) == 1)');
				var readData = read_until(data, dataoffset, ';');
				var chrs = readData[0];
				var readdata = readData[1];
				dataoffset += chrs + 1;
				break;
			case "d":
				typeconvert = new Function('x', 'return parseFloat(x)');
				var readData = read_until(data, dataoffset, ';');
				var chrs = readData[0];
				var readdata = readData[1];
				dataoffset += chrs + 1;
				break;
			case "n":
				readdata = null;
				break;
			case "s":
				var ccount = read_until(data, dataoffset, ':');
				var chrs = ccount[0];
				var stringlength = ccount[1];
				dataoffset += chrs + 2;

				var readData = read_chrs(data, dataoffset+1, parseInt(stringlength));
				var chrs = readData[0];
				var readdata = readData[1];
				dataoffset += chrs + 2;
				if(chrs !== parseInt(stringlength) && chrs !== readdata.length){
					error('SyntaxError', 'String length mismatch');
				}
				break;
			case "a":
				var readdata = {};

				var keyandchrs = read_until(data, dataoffset, ':');
				var chrs = keyandchrs[0];
				var keys = keyandchrs[1];
				dataoffset += chrs + 2;

				for(var i = 0;i < parseInt(keys);i++){
					var kprops = _unserialize(data, dataoffset);
					var kchrs = kprops[1];
					var key = kprops[2];
					dataoffset += kchrs;

					var vprops = _unserialize(data, dataoffset);
					var vchrs = vprops[1];
					var value = vprops[2];
					dataoffset += vchrs;

					readdata[key] = value;
				}

				dataoffset += 1;
				break;
			default:
				error('SyntaxError', 'Unknown / Unhandled data type(s): ' + dtype);
				break;
		}
		return [dtype, dataoffset - offset, typeconvert(readdata)];
	};
	return _unserialize(data, 0)[2];
}

$("#method").change(function () {
	$.ajax({
		url: "request/hub/method/param",
		type: "POST",
		data:  {
			method: $(this).val()
		},
		success: function(data){
			var getData = $("#method-opt");
			if(data.length > 0){
				var obj = $.parseJSON(data);
				var itemHTML = "";
				for (var i = 0; i < obj.getMethodOption.length; i++) {
					var object = obj.getMethodOption[i];
					itemHTML += '<div class="form-group"><label>' + object.name + '</label>';
					switch(object.type){
						case "input":
							itemHTML += '<input type="text" placeholder="' + object.placeholder + '" name="' + object.var_name + '" class="form-control">';
						break;
						case "select":
							var selection = unserialize(object.selection);
							itemHTML += '<select class="form-control" name="' + object.var_name + '">';
							for (var item in selection) {
								itemHTML += '<option value="' + selection[item] + '">' + item + '</option>';
							}
							itemHTML += '</select>';
						break;
					}
					itemHTML += "</div>";
				}
				getData.html(itemHTML);
			} else {
				getData.html(null);
			}
		},
		error: function(){}
	});
}).change();