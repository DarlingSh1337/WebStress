

$(".round-slider-info").roundSlider({
    radius: 60,
    width: 12,
    handleSize: "+0",
    sliderType: "min-range",
    value: 65
});


$(".round-slider-danger").roundSlider({
    radius: 60,
    width: 12,
    handleSize: "+0",
    sliderType: "min-range",
    value: 75
});


$(".round-slider-success").roundSlider({
    radius: 60,
    width: 12,
    handleSize: "+0",
    sliderType: "min-range",
    value: 45
});


$(".round-slider-warning").roundSlider({
    radius: 60,
    width: 12,
    handleSize: "+0",
    sliderType: "min-range",
    value: 80
});


$(".round-slider-primary").roundSlider({
    radius: 60,
    width: 12,
    handleSize: "+0",
    sliderType: "min-range",
    value: 73
});


$(".round-slider-secondary").roundSlider({
    radius: 60,
    width: 12,
    handleSize: "+0",
    sliderType: "min-range",
    value: 65
});

$(".round-slider-dark").roundSlider({
    radius: 60,
    width: 12,
    handleSize: "+0",
    sliderType: "min-range",
    value: 43
});


$(".round-slider-white").roundSlider({
    radius: 60,
    width: 12,
    handleSize: "+0",
    sliderType: "min-range",
    value: 57
});


