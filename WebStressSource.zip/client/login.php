<?php 
         ob_start();
       require_once 'includes/configuration.php';
       require_once 'includes/init.php';
       $page = "Login Portal";
     
         if ($user -> LoggedIn()){
     header('Location: home');
     exit;
       }


/*if(!empty($_COOKIE['ddos_key']))
    {
            end();
    }
    else 
        {

    header('Location: verify.php');

    }*/
  
  unset($_SESSION['captcha']);
$_SESSION['captcha'] = rand(1, 100);
$x1 = rand(2,10);
$x2 = rand(1,5);
$x = SHA1(($x1 + $x2).$_SESSION['captcha']);

?>

<?php
       
         if (isset($_GET['session'])){
if($_GET['session'] == "rip"){

    echo '
  <div class="alert alert-icon-warning alert-dismissible mb-0" role="alert">
       <button type="button" class="close" data-dismiss="alert">&times;</button>
      <div class="alert-icon icon-part-warning">
       <i class="fa fa-exclamation-triangle"></i>
      </div>
      <div class="alert-message">
        <span><strong>Warning:</strong> Session Token Expired!</span>
      </div>
      </div>
  ';

                }
            }

      
            ?>
       <?php
      
      // activate the account
//if ($type && preg_match('/activate/i', $type) && !empty($_REQUEST['actcode'])) {
        if (!empty($_REQUEST['actcode'])) {
            $activation = $odb->prepare("SELECT ID, activation FROM users WHERE activation_code = :actcode");
            $activation->execute(array(':actcode' => $_REQUEST['actcode']));
            $result    = $activation->fetch(PDO::FETCH_ASSOC);
            $uid       = $result['ID'];
            $act_value = $result['activation'];
            if (empty($uid)) {
        // the details needs to be logged
                die(error('We encounter an error. Please try again later.'));
            } else if ($act_value == 0) {
                $updatesql = $odb->prepare("UPDATE users SET activation = ? WHERE ID = ? AND activation_code = ?");
                $updatesql->execute(array(1, $uid, $_REQUEST['actcode']));
                $mesg = 'Your account hase been activated!!. Please continue to login';
        echo '<script type="text/javascript">';
  echo 'setTimeout(function () { swal({
  position: "top-end",
  toast: true,
  type: "success",
  title: "Success, Account activated!",
  showConfirmButton: false,
  timer: 4500
})';
  echo ' }, 1000);</script>';
        
            } else {
        echo '<script type="text/javascript">';
  echo 'setTimeout(function () { swal({
  position: "top-end",
  toast: true,
  type: "info",
  title: "Your account hase been activated!! already",
  showConfirmButton: false,
  timer: 4500
})';
  echo ' }, 1000);</script>';
               
            }

        }
    
      if(empty($_COOKIE['theme']))
    {
    $SQLC = $odb->prepare("SELECT `theme` FROM `settings` LIMIT 1");
          $SQLC -> execute();
                    $themee = $SQLC -> fetchColumn(0);
            $theme = $themee;
    }
else
{
            $theme = $_COOKIE['theme'];;
    } 
  
  

        ?>

<!DOCTYPE html>
<html lang="en">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0,minimal-ui">
      <title><?php echo $sitename; ?> - <?php echo $page; ?></title>
      <link rel="shortcut icon" sizes="196x196" href="logo.png">
      <link rel="apple-touch-icon" href="logo.png" sizes="120x120">
      <link rel="apple-touch-icon" href="logo.png" sizes="152x152">
      <link rel="apple-touch-icon" href="logo.png" sizes="180x180">
      <link rel="shortcut icon" href="logo.png">
      <meta content="Welcome to Login of Webstress the best IP Stresser / booter in 2020, Login today and start boot for free." name="description">
      <meta name="keywords" content="free ip stresser,free ip booter,booter,ip stresser,stresser,booter">
      <meta name="msapplication-TileColor" content="#FFFFFF">
      <meta name="msapplication-TileImage" content="https://webstress.gg/app/landing/assets/img/icons/favicon-144.png">
      <meta name="msapplication-config" content="https://webstress.gg/app/landing/assets/img/icons/browserconfig.xml">
      <link rel="canonical" href="https://webstress.gg/login">
      <meta name="audience" content="all">
      <meta name="author" content="Webstress.gg">
      <meta property="og:type" content="website">
      <meta property="og:locale" content="en_US">
      <meta property="og:description" content="Webstress is the best IP Stresser / Booter ! We provide free and paid services.">
      <meta property="og:site_name" content="Webstress.gg">
      <meta property="og:url" content="https://webstress.gg/login">
      <meta property="og:image" content="logo.png">
      <meta property="og:title" content="Webstress is the best IP Stresser / Booter">
      <script async="" src="assets/app.js" charset="UTF-8" crossorigin="*"></script><script type="text/javascript" async="" src="assets/atrk.js"></script><script async="" src="assets/1epjsbcvf" charset="UTF-8" crossorigin="*"></script><script type="application/ld+json">{"@context": "https://schema.org","@type": "Organization","name": "Webstress","url": "https://Webstress.gg","logo": "https://webstress.gg/src/landing/assets/img/logo.png"}</script>
      <meta name="twitter:card" content="summary">
      <meta name="twitter:site" content="Webstress.gg">
      <meta name="twitter:title" content="WebStress - The best IP Stresser / Booter">
      <meta name="twitter:domain" content="Webstress.gg">
      <meta name="twitter:creator" content="">
      <meta name="twitter:description" content="Webstress is the best IP Stresser / booter in 2020, We also provide free and paid ip stresser / booter services">
      <meta name="twitter:image" content="https://webstress.gg/app/landing/assets/img/logo.png">
      <link rel="stylesheet" href="assets/template.min.css">
      <link href="assets/toastr.min.css" rel="stylesheet">
      <script async="" src="assets/js"></script><script>
         window.dataLayer = window.dataLayer || [];
         function gtag(){dataLayer.push(arguments);}
         gtag('js', new Date());
         gtag('config', 'UA-184475903-1');
      </script>
   </head>
   <body>
    <script>
    var answer="<?php echo $x; ?>";
</script>
      <div class="container-scroller">
         <div class="container-fluid page-body-wrapper">
            <div class="main-panel">
               <div class="content-wrapper">
                  <div class="row d-flex justify-content-center login-form">
                     <div class="col-md-8">
                        <div class="card">
                           <div class="card-body">
                              <center><img class="row login-logo" src="assets/logo.png" alt="WebStress Logo"></center>
                              <div class="row">
                                 <div class="col-xl-7">
                                    <h2 class="card-title">Login portal</h2>
                                    <div id="alert" style="display:none"></div>
                                       <div class="form-group">
                                          Username
                                         <input type="text" id="username" class="form-control input-shadow" placeholder="Enter your Username">
                                       </div>
                                       <div class="form-group">
                                          Password
                                          <input type="password" id="password" class="form-control input-shadow"  placeholder="Enter Your Password">
                                       </div>
                                       <div class="form-group">
                                          Captcha
                                          <input type="text" class="form-control" id="question" placeholder="<?php echo ' '.$x1.'+'.$x2.'?'; ?>">
                                       </div>
      <div class="form-group">
                <input type="checkbox" value="on" id="hideme" />
                <label for="hideme">Hide My name</label>
       </div>
                                       <div class="row">
      <div id="hidebtn" >
       <button type="button" class="btn btn-primary btn-block" id="login" onclick="login()">Sign In</button>
      </div>
      <div  id="loader" style="display:none" >
       <button type="button" class="btn btn-primary btn-block" id="login" onclick="login()">Please Wait <i class="fa fa-spinner fa-spin"></i></button>
      </div>
                                          <div class="col-md-6">
                                            <a href="./register" class="btn btn-primary btn-block">Register</a>
                                          </div>
                                       </div>
                                 </div>
                                 <div class="border-left ml-3"></div>
                                 <div class="col-xl-4 ml-4 text-center login-custom">
                                    <h5>WebStress.gg</h5>
                                    <h1 class="login-h1"><small><i>Login before use the IP Stresser service</i></small></h1>
                                    <div class="border-bottom mb-3 mt-3"></div>
                                    <p>WebStress.gg is the best layer4 and layer7 ip stresser / web booter ! Join our telegram to stay updated about the ip stresser !</p>
                                    <a href="https://t.me/webstresse" target="_blank" type="button" class="btn btn-outline-primary btn-rounded btn-fw btn-xs">Telegram</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>

          <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->

         

         <noscript>
            <img alt="Alexa rank" src="https://certify.alexametrics.com/atrk.gif?account=QR/Ov1khOY20xx" style="display:none" height="1" width="1" alt="" />
         </noscript>
      </div>
      <?php ?>
  <script>


function login()
{
swal({
  position: 'center',
  toast: false,
  type: 'info',
  title: 'Cheking Login Parameters..',
  showConfirmButton: false,
  timer: 3500
  
});
var user=$('#username').val();
var password=$('#password').val();
 let hideme = $('#hideme:checked').val();
 var question=$('#question').val();

            if (hideme === undefined) {
                hideme = 'off';
            }
document.getElementById("alert").style.display="none";
document.getElementById("loader").style.display="inline";
document.getElementById("hidebtn").style.display="none";
var xmlhttp;
if (window.XMLHttpRequest)
  {
  xmlhttp=new XMLHttpRequest();
  }
else
  {
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("alert").innerHTML=xmlhttp.responseText;
  document.getElementById("loader").style.display="none";
  document.getElementById("alert").style.display="inline";
  document.getElementById("hidebtn").style.display="inline";
  if (xmlhttp.responseText.search("Login Successful") !== -1)
  {
        swal({
  position: 'center',
  toast: false,
  type: 'success',
  title: 'Signed in successfully!',
  showConfirmButton: true,
  timer: 2500
  
});

  setInterval(function(){window.location="home"},3000);
    }
    }
  }
xmlhttp.open("POST","functions/login.php?type=login",true);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("user=" + user + "&password=" + password + "&hideme=" + hideme + "&question=" + question + "&answer=" + answer);
}
</script>
<script src="assets/node_modules/sweetalert2/dist/sweetalert2.all.min.js"></script>
        <link rel="stylesheet" href="assets/node_modules/sweetalert2/dist/sweetalert2.min.css">
   <script src="assets/toastr/toastr.min.js"></script>
      <script src="assets/base.js"></script>
      <script src="assets/template.js"></script>
      <script src="assets/todolist.js"></script>
      <script src="assets/toastr.min.js"></script>
      <script src="assets/tooltips.js"></script>
      <script src="assets/getnotif.js"></script>
      <script src="assets/sha256.min.js"></script>


      <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/popper.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="assets/plugins/notifications/css/lobibox.min.css"/>
  
  <!-- sidebar-menu js -->
  <script src="assets/js/sidebar-menu.js"></script>
  
  <!-- Custom scripts -->
  <script src="assets/js/app-script.js"></script>
   </body>
</html>