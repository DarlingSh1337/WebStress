<?php
include('header.php');

?>
<div class="page-wrapper">
								
	 <main id="main-container" style="min-height: 536px;">
  <div class="content">
 <div class="row">
<?php
//echo '<pre>';
//print_r($_POST);
//echo $_POST['payment_status'];
 if($_POST['txn_id'] != ''){
     $username = $_SESSION['ID'];
     $SQL = $odb -> prepare("SELECT `balance`, `username` FROM `users` WHERE `username` = :usuario"); 
     $SQL -> execute(array(":usuario" => $_SESSION['username']));
    $getinfo = $SQL -> fetch(PDO::FETCH_ASSOC);
    $balance = $getinfo['balance'];
    $receivernewamount = $balance+$_POST['mc_gross'];
     $updateReceiver = $odb -> prepare("UPDATE `users` SET `balance` = '".$receivernewamount."' WHERE `ID` = '".$username."'");
    $updateReceiver -> execute(); 
    $insert = $odb->prepare("INSERT INTO `AddFunds` VALUES (NULL,?,?,?,?)");
    $insert->execute(array($_SESSION['ID'],$_POST['txn_id'],$_POST['mc_gross'],time()));
	 
					echo '<script type="text/javascript">';
  echo 'setTimeout(function () { swal({
  position: "top-end",
  type: "success",
  title: "Success",
  text: "Balance Added to Your account!!"
  showConfirmButton: false,
  timer: 3000
})';
  echo ' }, 1000);</script>';
     echo '<meta http-equiv="Refresh" content="3; url=index.php">';
 }
?>
	 
	 </div>
	  </div>
		 </main>