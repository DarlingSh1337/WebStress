<head>
  <meta http-equiv="refresh" content="0; URL=http://localhost/welcome/" />
</head>